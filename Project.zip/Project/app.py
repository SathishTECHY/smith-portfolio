from flask import Flask, render_template, request, jsonify
from backend import ATM, AtmOperationImpl

app = Flask(__name__, static_url_path='/static')
op = AtmOperationImpl()
atmnumber = 12345
atmpin = 123

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/api/atm', methods=['POST'])
def atm_operation():
    data = request.get_json()
    atmNumber = data.get('atmNumber')
    pin = data.get('pin')
    if atmnumber == atmNumber and atmpin == pin:
        choice = data.get('choice')
        if choice == 1:
            balance = op.viewBalance()
            return jsonify({'message': 'Available Balance is: {}'.format(balance)})
        elif choice == 2:
            withdrawAmount = data.get('amount')
            message = op.withdrawAmount(withdrawAmount)
            return jsonify({'message': message})
        elif choice == 3:
            depositAmount = data.get('amount')
            message = op.depositAmount(depositAmount)
            return jsonify({'message': message})
        elif choice == 4:
            mini_statement = op.viewMiniStatement()
            return jsonify({'message': mini_statement})
        elif choice == 5:
            return jsonify({'message': 'Collect your ATM Card. Thank you for using ATM Machine!'})
        else:
            return jsonify({'error': 'Please enter correct choice'}), 400
    else:
        return jsonify({'error': 'Incorrect Atm Number or pin'}), 401

if __name__ == "__main__":
    app.run(debug=True)
