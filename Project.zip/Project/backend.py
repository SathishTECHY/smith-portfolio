class ATM:
    def __init__(self):
        self.balance = 0.0

    def getBalance(self):
        return self.balance

    def setBalance(self, balance):
        self.balance = balance


class AtmOperationImpl:
    def __init__(self):
        self.atm = ATM()
        self.ministmt = {}

    def viewBalance(self):
        return self.atm.getBalance()

    def withdrawAmount(self, withdrawAmount):
        if withdrawAmount % 500 == 0:
            if withdrawAmount <= self.atm.getBalance():
                self.ministmt[withdrawAmount] = "Amount Withdrawn"
                self.atm.setBalance(self.atm.getBalance() - withdrawAmount)
                return "Collect the Cash " + str(withdrawAmount)
            else:
                return "Insufficient Balance!"
        else:
            return "Please enter the amount in multiples of 500"

    def depositAmount(self, depositAmount):
        self.ministmt[depositAmount] = "Amount Deposited"
        self.atm.setBalance(self.atm.getBalance() + depositAmount)
        return str(depositAmount) + " Deposited Successfully!"

    def viewMiniStatement(self):
        return self.ministmt
