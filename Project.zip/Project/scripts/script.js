document.addEventListener('DOMContentLoaded', function() {
    const atmForm = document.getElementById('atmForm');

    atmForm.addEventListener('submit', function(event) {
        event.preventDefault();
        const atmNumber = document.getElementById('atmNumber').value;
        const pin = document.getElementById('pin').value;
        
        // Validate ATM number and PIN (replace with your validation logic)
        const isValidLogin = validateLogin(atmNumber, pin);

        if (isValidLogin) {
            // Redirect to operations page
            window.location.href = 'operations.html';
        } else {
            alert('Invalid ATM number or PIN. Please try again.');
        }
    });

    // Dummy validation function (replace with actual validation logic)
    function validateLogin(atmNumber, pin) {
        return atmNumber === '12345' && pin === '123';
    }
});
